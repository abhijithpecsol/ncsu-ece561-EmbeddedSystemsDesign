#ifndef MY_MATH_H
#define MY_MATH_H

#define M_PI (3.14159265f)
#define PI_OVER_180 (3.1415927/180.0)
#define M_PI_2 (M_PI/2.0)
#define M_PI_4 (M_PI/4.0)

#endif // MY_MATH_H
