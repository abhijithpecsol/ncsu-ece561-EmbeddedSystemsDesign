#ifndef DELAY_H
#define DELAY_H
extern void Delay(uint32_t dlyTicks);

#endif
