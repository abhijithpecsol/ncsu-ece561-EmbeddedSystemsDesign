#ifndef DELAY_H
#define DELAY_H
#include <stdint.h>

extern void Delay(uint32_t dlyTicks);
extern void ShortDelay(uint32_t dlyTicks);
#endif
// *******************************ARM University Program Copyright � ARM Ltd 2013*************************************   
