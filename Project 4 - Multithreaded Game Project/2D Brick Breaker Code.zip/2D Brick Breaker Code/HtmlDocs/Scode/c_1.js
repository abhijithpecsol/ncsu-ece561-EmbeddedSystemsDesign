﻿function gotosrc(idx){
 switch ( idx ) { default : 
 break; 
 } 
 }